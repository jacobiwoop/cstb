import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { Calendar, Tag, User, ArrowLeft, Facebook, Twitter, Linkedin, Heart, MessageSquare, Send } from 'lucide-react';

export const ArticlePage = () => {
  const { id } = useParams();

  const [likesCount, setLikesCount] = useState(124);
  const [isLiked, setIsLiked] = useState(false);
  
  const [comments, setComments] = useState([
    { id: 1, author: "Jean Dupont", text: "Totalement en accord avec ces revendications. Il est temps de se faire entendre !", date: "Il y a 2 heures" },
    { id: 2, author: "Marie Mensah", text: "Je serai présente à la Bourse du Travail ce vendredi. Solidarité !", date: "Il y a 5 heures" }
  ]);
  const [newComment, setNewComment] = useState("");

  const handleLike = () => {
    if (isLiked) {
      setLikesCount(prev => prev - 1);
      setIsLiked(false);
    } else {
      setLikesCount(prev => prev + 1);
      setIsLiked(true);
    }
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    
    const comment = {
      id: Date.now(),
      author: "Utilisateur Anonyme",
      text: newComment,
      date: "À l'instant"
    };
    
    setComments([comment, ...comments]);
    setNewComment("");
  };

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [id]);

  // Mock article data (in a real app, this would be fetched based on the ID)
  const article = {
    title: "Appel à la mobilisation générale pour les droits des travailleurs",
    category: "Communiqué",
    date: "2 Avril 2026",
    author: "Bureau Directeur National",
    image: "https://storage.googleapis.com/aistudio-ext-files/0/file_62b17d5985864117.jpeg",
    content: `
      <p class="text-2xl font-light text-[#1e293b] mb-10 leading-snug">La Confédération Syndicale des Travailleurs du Bénin (CSTB) appelle l'ensemble des travailleurs, des secteurs public et privé, à une mobilisation générale et pacifique pour la défense de nos acquis sociaux historiques.</p>
      
      <h2 class="text-3xl font-sans font-bold text-[#0f172a] mt-12 mb-6">Un contexte de précarité grandissante</h2>
      <p class="text-lg text-[#6b7280] leading-relaxed mb-6">Face à l'inflation galopante et aux récentes mesures gouvernementales qui menacent le pouvoir d'achat des ménages béninois, il est de notre devoir de réagir. Les travailleurs ne peuvent plus supporter seuls le poids des réformes économiques sans aucune contrepartie sociale.</p>
      
      <blockquote class="border-l-4 border-[#007cba] bg-[#f8fafc] p-8 my-10 rounded-r-lg shadow-custom-4">
        <p class="text-xl italic text-[#1e293b] mb-4">"La ligne de la CSTB, c'est une ligne de conduite générale qui œuvre ardemment à l'amélioration constante des conditions de vie et de travail de la classe ouvrière."</p>
        <footer class="text-sm font-bold text-[#6b7280]">— Nagnini M. KASSA MAMPO, Secrétaire Général Confédéral</footer>
      </blockquote>
      
      <h2 class="text-3xl font-sans font-bold text-[#0f172a] mt-12 mb-6">Nos revendications principales</h2>
      <p class="text-lg text-[#6b7280] leading-relaxed mb-6">Lors de la dernière session extraordinaire du Comité Confédéral National (CCN), nous avons arrêté les points de revendication suivants :</p>
      <ul class="list-disc list-inside text-lg text-[#6b7280] leading-relaxed mb-6 space-y-3 marker:text-[#007cba]">
        <li>La revalorisation immédiate du Salaire Minimum Interprofessionnel Garanti (SMIG).</li>
        <li>L'arrêt des licenciements abusifs dans le secteur privé.</li>
        <li>L'amélioration des conditions de travail dans les hôpitaux et les écoles publiques.</li>
        <li>Le respect strict des libertés syndicales et du droit de grève.</li>
      </ul>
      
      <h2 class="text-3xl font-sans font-bold text-[#0f172a] mt-12 mb-6">Appel à l'action</h2>
      <p class="text-lg text-[#6b7280] leading-relaxed mb-6">Nous invitons tous les syndicats affiliés, les militants et sympathisants à se tenir prêts pour les actions à venir. Un grand rassemblement est prévu à la Bourse du Travail de Cotonou ce vendredi. Venez nombreux pour faire entendre notre voix. L'union fait la force, et c'est ensemble que nous arracherons de nouvelles victoires pour la classe ouvrière.</p>
    `
  };

  return (
    <div className="bg-white min-h-screen font-sans pt-24 pb-16">
      {/* Article Header */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 pb-12">
        <Link to="/actualites" className="inline-flex items-center gap-2 text-[#007cba] font-bold hover:text-[#005a87] transition-colors mb-8">
          <ArrowLeft size={20} /> Retour aux actualités
        </Link>
        
        <div className="flex items-center gap-3 mb-6">
          <span className="bg-[#007cba] text-white text-xs font-bold px-3 py-1 uppercase tracking-wider rounded-[6px]">
            {article.category}
          </span>
          <span className="text-[#6b7280] text-sm font-mono flex items-center gap-1">
            <Calendar size={14} /> {article.date}
          </span>
        </div>

        <h1 className="text-4xl md:text-5xl lg:text-6xl font-sans font-black text-[#0f172a] leading-tight mb-8">
          {article.title}
        </h1>

        <div className="flex items-center justify-between border-y border-[#e2e8f0] py-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#e2e8f0] rounded-full flex items-center justify-center text-[#6b7280]">
              <User size={20} />
            </div>
            <div>
              <p className="text-sm font-bold text-[#0f172a]">{article.author}</p>
              <p className="text-xs text-[#6b7280]">CSTB Bénin</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <span className="text-sm font-bold text-[#6b7280] hidden sm:inline">Partager :</span>
            <button className="w-8 h-8 rounded-full bg-[#f1f5f9] flex items-center justify-center text-[#6b7280] hover:bg-[#1877F2] hover:text-white transition-colors">
              <Facebook size={14} />
            </button>
            <button className="w-8 h-8 rounded-full bg-[#f1f5f9] flex items-center justify-center text-[#6b7280] hover:bg-[#1DA1F2] hover:text-white transition-colors">
              <Twitter size={14} />
            </button>
            <button className="w-8 h-8 rounded-full bg-[#f1f5f9] flex items-center justify-center text-[#6b7280] hover:bg-[#0A66C2] hover:text-white transition-colors">
              <Linkedin size={14} />
            </button>
          </div>
        </div>
      </div>

      {/* Featured Image */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="aspect-video w-full overflow-hidden rounded-[12px] shadow-custom-1"
        >
          <img 
            src={article.image} 
            alt={article.title} 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </motion.div>
      </div>

      {/* Article Content */}
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <article 
          className="article-content"
          dangerouslySetInnerHTML={{ __html: article.content }}
        />

        {/* Interaction Bar */}
        <div className="mt-12 py-6 border-y border-[#e2e8f0] flex items-center justify-between">
          <div className="flex items-center gap-6">
            <button 
              onClick={handleLike}
              className={`flex items-center gap-2 font-bold transition-colors ${isLiked ? 'text-red-500' : 'text-[#6b7280] hover:text-red-500'}`}
            >
              <Heart size={24} className={isLiked ? "fill-current" : ""} />
              <span>{likesCount} {likesCount > 1 ? 'J\'aimes' : 'J\'aime'}</span>
            </button>
            <div className="flex items-center gap-2 font-bold text-[#6b7280]">
              <MessageSquare size={24} />
              <span>{comments.length} {comments.length > 1 ? 'Commentaires' : 'Commentaire'}</span>
            </div>
          </div>
        </div>
        
        {/* Tags */}
        <div className="mt-8 flex flex-col sm:flex-row sm:items-center gap-4">
          <div className="flex items-center gap-2 text-[#6b7280] font-bold text-sm uppercase tracking-wider">
            <Tag size={16} /> Mots-clés :
          </div>
          <div className="flex flex-wrap gap-2">
            <span className="bg-[#f1f5f9] text-[#6b7280] text-sm font-medium px-4 py-1.5 rounded-full hover:bg-[#e2e8f0] cursor-pointer transition-colors">Syndicalisme</span>
            <span className="bg-[#f1f5f9] text-[#6b7280] text-sm font-medium px-4 py-1.5 rounded-full hover:bg-[#e2e8f0] cursor-pointer transition-colors">Mobilisation</span>
            <span className="bg-[#f1f5f9] text-[#6b7280] text-sm font-medium px-4 py-1.5 rounded-full hover:bg-[#e2e8f0] cursor-pointer transition-colors">Droits</span>
          </div>
        </div>

        {/* Comments Section */}
        <div className="mt-16">
          <h3 className="text-2xl font-sans font-bold text-[#0f172a] mb-8">Commentaires ({comments.length})</h3>
          
          {/* Add Comment Form */}
          <form onSubmit={handleAddComment} className="mb-12 bg-[#f8fafc] p-6 rounded-[12px] border border-[#e2e8f0]">
            <h4 className="text-lg font-bold text-[#0f172a] mb-4">Laisser un commentaire</h4>
            <div className="relative">
              <textarea
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Votre message..."
                className="w-full bg-white border border-[#cbd5e1] rounded-[8px] p-4 min-h-[120px] focus:outline-none focus:border-[#007cba] focus:ring-1 focus:ring-[#007cba] resize-y"
                required
              />
              <button 
                type="submit"
                className="absolute bottom-4 right-4 bg-[#007cba] text-white p-2 rounded-full hover:bg-[#005a87] transition-colors shadow-custom-4 disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={!newComment.trim()}
              >
                <Send size={18} />
              </button>
            </div>
          </form>

          {/* Comments List */}
          <div className="space-y-6">
            {comments.map(comment => (
              <div key={comment.id} className="flex gap-4">
                <div className="w-12 h-12 bg-[#e2e8f0] rounded-full flex items-center justify-center text-[#6b7280] shrink-0">
                  <User size={24} />
                </div>
                <div className="flex-1 bg-white border border-[#e2e8f0] p-5 rounded-[12px] rounded-tl-none shadow-sm">
                  <div className="flex items-center justify-between mb-2">
                    <h5 className="font-bold text-[#0f172a]">{comment.author}</h5>
                    <span className="text-xs text-[#94a3b8] font-mono">{comment.date}</span>
                  </div>
                  <p className="text-[#475569] leading-relaxed">{comment.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
