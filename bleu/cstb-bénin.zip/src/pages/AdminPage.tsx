import React, { useEffect } from 'react';
import { Lock } from 'lucide-react';

export default function AdminPage() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="bg-[#f1f5f9] min-h-screen font-sans pt-24 pb-16 flex flex-col items-center justify-center">
      <div className="bg-white p-10 rounded-[12px] shadow-custom-2 border border-[#e2e8f0] max-w-md w-full text-center">
        <div className="w-16 h-16 bg-[#007cba]/10 text-[#007cba] rounded-full flex items-center justify-center mx-auto mb-6">
          <Lock size={32} />
        </div>
        <h1 className="text-2xl font-bold text-[#0f172a] mb-2">Espace Administration</h1>
        <p className="text-[#6b7280] mb-8">Veuillez vous connecter pour accéder au tableau de bord.</p>
        
        <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
          <div>
            <input type="text" placeholder="Identifiant" className="w-full bg-[#f8fafc] border border-[#cbd5e1] rounded-[6px] p-3 focus:outline-none focus:border-[#007cba]" required />
          </div>
          <div>
            <input type="password" placeholder="Mot de passe" className="w-full bg-[#f8fafc] border border-[#cbd5e1] rounded-[6px] p-3 focus:outline-none focus:border-[#007cba]" required />
          </div>
          <button type="submit" className="w-full bg-[#0f172a] text-white font-bold py-3 rounded-[6px] hover:bg-[#1e293b] transition-colors">
            Se connecter
          </button>
        </form>
      </div>
    </div>
  );
}
